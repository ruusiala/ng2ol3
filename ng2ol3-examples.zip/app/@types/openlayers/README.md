# Installation
> `npm install --save @types/openlayers`

# Summary
This package contains type definitions for OpenLayers v3.6.0 (http://openlayers.org/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/openlayers

Additional Details
 * Last updated: Thu, 25 Aug 2016 16:56:08 GMT
 * File structure: Mixed
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: ol

# Credits
These definitions were written by Wouter Goedhart <https://github.com/woutergd>.
