# Installation
> `npm install --save @types/jspdf`

# Summary
This package contains type definitions for jsPDF v1.1.135 (https://github.com/MrRio/jsPDF).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/jspdf

Additional Details
 * Last updated: Wed, 21 Sep 2016 20:25:54 GMT
 * File structure: DeclareModule
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: none

# Credits
These definitions were written by Amber Schühmacher <https://github.com/amberjs>.
